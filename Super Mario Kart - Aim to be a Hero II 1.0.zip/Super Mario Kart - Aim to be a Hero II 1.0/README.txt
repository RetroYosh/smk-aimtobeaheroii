Super Mario Kart - Aim to be a Hero II

This is a follow-up hack to a Super Mario Kart hack I made over 2 years ago, subtitled "Aim to be a Hero". With this sequel, I aimed to make a hack that was an overall improvement over my previous effort, with better track designs, more diverse themes with custom background graphics, and reimplementing the feather item in some of the track themes.

Just like the previous hack there are 20 new tracks across the 4 cups, with 5 tracks each, with 3 different speed classes, being 50cc, 100cc, and the unlockable 150cc. The new track themes include: Shroom Stadium, Bloom Village, Boo Boardwalk, Dawn Desert, Seaside Beach, Magma Slide, Arctic Edge, and of course Rainbow Road.

This hack also tweaks the scoring system, with 9 pts for 1st, 7 pts for 2nd, 5 pts for 3rd, 4 pts for 4th, 3 pts for 5th, 2 pts for 6th, 1 pt for 7th, and 0 pts for 8th.

Hack by RetroYosh